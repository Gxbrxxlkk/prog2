#include <iostream>
#include <string>
#include <cmath>
#include <vector>

//classe base
class FuncionarioAssalariado{

    public:

    FuncionarioAssalariado(): nome{" "}, cpf{" "}, salario{-1.0} {}
    FuncionarioAssalariado(std::string anome, std::string acpf, double sal):
    nome{anome}, cpf{acpf} {
        if (sal > 0) salario = sal;
        else salario = -1;
    } 

    //getters and setters
    std::string getNome() {return nome;}
    std::string getCpf() {return cpf;}
    double getSalario() {return salario;}

    //fazer os setters


    private:
        std::string nome;
        std::string cpf;
        double salario;


};

//classe derivada (herança)
class FuncionarioComissionado: public FuncionarioAssalariado {
    public:

        FuncionarioComissionado(std::string nome, std::string cpf, double salario): taxa{0.0}, totalVendas{0.0} {}
        FuncionarioComissionado(std::string anome, std::string acpf, double sal, double ataxa, double atotalVendas):
            FuncionarioAssalariado(anome, acpf, sal), taxa{ataxa}, totalVendas{atotalVendas} {
                if (atotalVendas > 0)
                {
                    totalVendas = atotalVendas;
                } else totalVendas = 0.0;
                
                if (ataxa > 0 && ataxa <= 100)
                {
                    taxa = ataxa;
                } else taxa = 0.0;
            }

        //redefine o método getSalarario()
        double getSalario() {
            double salarioBase = FuncionarioAssalariado::getSalario();
            return salarioBase + (totalVendas * taxa);
        }
    
    private:
    
        double taxa;
        double totalVendas;
}; 