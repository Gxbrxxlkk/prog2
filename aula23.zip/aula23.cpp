#include <iostream>
#include <string>
#include <cmath>
#include <vector>

class Ponto{
    friend class Utilitarios;
    
    public:

        Ponto(): x{0}, y{0} {cont++;} //construtor default
        Ponto(const Ponto &p) {
        x = p.x;
        y = p.y;
        cont++;
        }//construtor por cópia
        Ponto(int ax, int ay): x{ax}, y{ay} {cont++;} //Construtor por parametro

        //getters
        //precisa de um objeto para chama-los
        int getX() {return x;}
        int getY() {return y;}

        //pode ser chamado direto da classe
        static int getCont() {return cont;}

         //string formatada com as coordenadas
        std::string toString() {
            return "(" + std::to_string(x) + "," + std::to_string(y) + ")";
        }

        ~Ponto() {
            cont--;
        }


    private:
        int x;
        int y;
        inline static int cont{0}; //Uma cópia compartilhada por todos os objetos


};

class ListaPontos {
    friend class Utilitarios;

    public:
        ListaPontos(): pontos{} {}
        ListaPontos(std::vector<Ponto> & alista) : pontos{alista} {}

        void insere(Ponto &p) {
            pontos.push_back(p);
        } 
    private:
        std::vector <Ponto> pontos; //composição

};

class Utilitarios{
    //friend double distancia(const Ponto &p1, const Ponto &p2);
    
    public:


        static double menorDistancia(Ponto &p, const ListaPontos &listaPontos){
            if (!listaPontos.pontos.empty()) {
                double menor = distancia(p, listaPontos.pontos.at(0));
                for(int i{1}; i < listaPontos.pontos.size(); i++) {
                    double aux = distancia(p, listaPontos.pontos.at(i));
                    if (aux < menor) {
                        menor = aux;
                    }
        
                }
                return menor;
            } else return -1.0f;
            
        }
        static int totalPontosCriados() {
            return Ponto::getCont();
        }
    
    private:

        static double distancia(const Ponto &p1, const Ponto &p2) {
            int deltax = p2.x - p1.x;
            int deltay = p2.y - p1.y;
            return std::sqrt(deltax*deltax + deltay*deltay);
        }


};

//funcao que calcula a distancia entre dois pontos
// p1 = (x1, y1); p2 = (x2, y2)
// distancia = ((x2- x1)^2 + (y2 - y1)²)^1/2

// double distancia(const Ponto &p1, const Ponto &p2) {
    
//     int deltax = p2.x - p1.x;
//     int deltay = p2.y - p1.y;
//     return std::sqrt(deltax*deltax + deltay*deltay);
// }

int main() {
    Ponto p{}; //(0,0)
    //Ponto pinto{};
    ListaPontos lista{};
    // double d = distancia(p1,p2);
    Ponto p1{5,5};
    lista.insere(p1);
    Ponto p2{5,7};
    lista.insere(p2);
    Ponto p3{7,8};
    lista.insere(p3);
   
    
    double menorDist = Utilitarios::menorDistancia(p, lista);

    std::cout << "Menor distancia = " << std::to_string(menorDist) << std::endl;
    std::cout << "Quantidade de pontos = " << std::to_string(Utilitarios::totalPontosCriados()) << std::endl;
    // std::cout << "A distancia entre " + p1.toString() + " e " + p2.toString() + " É igual a " + std::to_string(d) << std::endl;

    // std::cout << "p1.cont = " << p1.getCont() << std::endl;
    // std::cout << "p2.cont = " << p2.getCont() << std::endl;
    // std::cout << "p3.cont = " << p3.getCont() << std::endl;

    return 0;
}