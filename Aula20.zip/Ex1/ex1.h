#include <string>

class Fatura {



    public:

        Fatura() : numero_de_peca{""}, desc_peca{""}, qtd_item_comprado{0}, preco_p_item{0.0f} {}
        Fatura(std::string numero, std::string descri, int quanti, float preco) 
            :numero_de_peca{numero}, desc_peca{descri}, qtd_item_comprado{quanti}, preco_p_item{preco} {
                if (quanti < 0) {
                    qtd_item_comprado = 0;
                } else qtd_item_comprado = quanti;
                if (preco < 0) {
                    preco_p_item = 0;
                } else preco_p_item = preco;
                
            }



        std::string getNumero(){
            return numero_de_peca;
        }
        std::string getDesc() {
            return desc_peca;
        }
        int getQtd() {
            return qtd_item_comprado;
        }
        float getPreco() {
            return preco_p_item;
        }
        float getTotalFatura() {
            return qtd_item_comprado * preco_p_item;
        }


        void setNumero(std::string numeropeca) {
            numero_de_peca = numeropeca;
        }
        void setDesc(std::string descripeca) {
            desc_peca = descripeca;
        }
        void setQtd(int quantidade) {
            if (quantidade < 0) {
                qtd_item_comprado = 0;
            } else qtd_item_comprado = quantidade;
        }
        void setPreco(float precopeca) {
            if (precopeca < 0) {
                preco_p_item = 0;
            } else preco_p_item = precopeca;
        }


    private:
        std::string numero_de_peca;
        std::string desc_peca;
        int qtd_item_comprado;
        float preco_p_item;

};
