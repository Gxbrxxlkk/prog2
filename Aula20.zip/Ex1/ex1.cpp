#include "ex1.h"
#include <iostream>

int main() {

    Fatura f1,f2{"1", "Monitor OLED", 7, 1456.79};

    f1.setDesc("Essa é a descricao da peca 1");
    f1.setNumero("22");
    f1.setPreco(13.12f);
    f1.setQtd(15);

    std::cout << "Informações iniciais das peças: " << std::endl;
    std::cout << f1.getNumero() << " " << f1.getDesc() << " " << f1.getPreco() << " " << f1.getQtd() << " " << f1.getTotalFatura() << std::endl;
    std::cout << f2.getNumero() << " " << f2.getDesc() << " " << f2.getPreco() << " " << f2.getQtd() << " " << f2.getTotalFatura() << std::endl;


    return 0;
}