/*
Programação orientada a objeto
componentes de um software q são reutilizaveis
atributos (nome, cor, tamanho) e comportamentos (calcular, mover e comunicar)  
*/

#include "aula20.h"
#include <iostream>

int main() {
    Conta c1{}, c2{"Gabriel Loss", "4321", 1, 500000.01f}; //cria objeto c1 e c2

    c1.setNome("Lauanda"); c1.setCpf("0302"); c1.setNumero(2); c1.setSaldo(33225.05f);
    
    c1.depositar(156);
    c1.sacar(312);

    //mostrando as informações
    std::cout << "Informações iniciais das contas: " << std::endl;
    std::cout << c1.getNome() << " " << c1.getCpf() << " " << c1.getNumero() << " " << c1.getSaldo() << std::endl;
    std::cout << c2.getNome() << " " << c2.getCpf() << " " << c2.getNumero() << " " << c2.getSaldo() << std::endl;



    return 0;
}