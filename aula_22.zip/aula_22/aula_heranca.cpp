//herança: modelar relações entre classe do tipo "é uma" "is-a"
//composição: relação "has-a"
//agregação

//exemplo, tentar fazer com ano bissexto