#include <format>
#include <iostream>
#include <string>

int main() {
    std::string s1{"Programacao C++"};
    std::string s2; // inicializa com a string vazia
    std::string s3;

    s2 = s1; //faz uma cópia
    s3.assign(s1); //recebe uma cópia de s1
    std::cout << std::format("s1 = {}\ns2 = {}\ns3 = {}\n", s1,s2,s3);
    
    // //modificação
    // s1[12] = 'c';
    // s2.at(12) = 'c';
    
    // std::cout << std::format("s1 = {}\ns2 = {}\ns3 = {}\n", s1,s2,s3);

    // //iterando numa string usando range-based for
    // for(char c: s3) {
    //     std::cout << c << " ";
    // }

    //concatenação
    std::string s4{s1 + " na UFMT"};
    s1.append(" eh facil"); //anexa ao final da string s1
    s3 += " eh dificil";

    // std::cout << std::format("\ns1 = {}\ns3 = {}\ns4 = {}\n", s1,s3,s4);

    // //comparações
    // std::cout <<s1.compare(s2) << "\n";
    // std::cout <<s1.compare(s4) << "\n";
    // std::cout <<s1.compare(s1) << "\n";

    //substring
    std::string s5 = s4.substr(19, 4);
    std::cout << std::format("\ns5 = {}\n", s5);

    //swap
    std::cout << std::format("\ns4 = {}\ns5 = {}\n", s4,s5);
    s4.swap(s5); //troca o conteudo das strings
    std::cout << std::format("\ns4 = {}\ns5 = {}\n", s4,s5);

    //estatisticas
    std::cout << std::format("\nCapacidade = {}\nTamanho = {}\nTam max = {}\nVazia = {}\n", s1.capacity(), s1.size(), s1.max_size(), s1.empty());
    //size() = numero de caracteres da string
    //empty() = booleano(string vazia?)
    //max_size() = tam max que a string pode ter
    //capacity() = espaco já reservado sem nova alocação

    //consultas numa string
    std::string esse1{"Programacao C++ eh muito chato, mas ha quem goste!"
                        "\n muitos alunos tem dificuldade, porque nao estudam."};

    std::cout << esse1 << std::endl;

    //consultas com find() e rfind()
    std::cout << esse1.find("muito") << "\n";
    std::cout << esse1.rfind("muito") << "\n";
    std::cout << esse1.rfind("laranja") << "\n";
    std::cout << std::string::npos << std::endl;
    std::cout << esse1.find_first_of("laranja") << "\n";
    std::cout << esse1.find_last_of("laranja") << "\n";
    std::cout << esse1.find_first_not_of("laranja") << "\n"; // o primeiro caracter antes do primeiro que estiver aqui dentro

    // //remocao de caracteres
    // esse1.erase(15);
    // std::cout << esse1 << "\n";

    // //substituição
    // esse1.replace(12, 3, "peiton, xanascript e C#");
    // std::cout << esse1 << "\n";

    //inserir numa string
    std::string esse2{"ceu nublado!"};
    esse2.insert(4, "azul ");
    std::cout << esse2 << "\n";

    return 0;
}