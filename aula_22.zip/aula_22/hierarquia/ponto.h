# include <string>
#include <iostream>

class Ponto{
    
    public:
        Ponto(): x{0.0}, y{0.0} {}
        Ponto(const Ponto &p): x{p.x}, y{p.y} {} //construtor de copia
        Ponto(double ax, double ay): x{ax}, y{ay} {}
        
        //getters
        double getx() {return x;}
        double gety() {return y;}

        //setters
        void setx(double ax) { x = ax;}
        void sety(double ay) { y = ay;}

        //retorna uma string com ponto formatado
        std::string toString() {
            std::string aux = "(" + std::to_string(x) + ", " + std::to_string(y) + ")";
            return aux;
        }


    
    
    
    private:
    
        double x; //Coordenada x
        double y; //Coordenada y

};