#include "ponto.h"


int main() {
    Ponto p1{}; //chama o construtor default
    Ponto p2{1.5,3.0}; //chama o construtor com parametro

    std::cout << p1.toString() << std::endl;
    std::cout << p2.toString() << std::endl;


    p1 = p2; // sobrecarga do operador de atribuicao padrao (=)
    Ponto p3{p2}; // construtor de copia padrao Ponto p3 = p2; <-- aqui não usa o construtor de copia, aqui é sobrecarga do operador de atribuicao default 
    std::cout << p3.toString() << std::endl;
    return 0;
}