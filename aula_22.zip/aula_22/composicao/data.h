#include <string>
#include <iostream>
#include <array>

class Data {

    public:
        Data() : dia{0}, mes{0}, ano{0} {}
        Data(const Data &d) : dia{d.dia}, mes{d.mes}, ano{d.ano} {
            std::cout << "\nCriando data por copia";
        } //construtor de cópia
        Data(int um_dia, int um_mes, int um_ano) {
            std::cout << "\nCriando data por parametro";
            std::array<int, 13> diaMes {0, 31, 28, 31, 30, 30, 30, 31, 31, 30, 31, 30, 31};

            //valida o mes
            if((um_mes >= 1) && (um_mes <= 12)) {
                mes = um_mes;
            } else {
                mes = 0;
            }

            //valida o dia
            if(mes != 0) {
                if((um_dia >= 1) && (um_dia <= diaMes[mes])) {
                    dia = um_dia;
                }
            } else {
                dia = 0;
            }

            //valida o ano
            if((mes != 0) && (dia != 0)) {
                if (um_ano >= 0) {
                    ano = um_ano;
                }
            }
        }
        

        std::string toString() {
            std::string aux = std::to_string(dia) + "-" + std::to_string(mes) + "-" + std::to_string(ano);
            return aux;
        }

        ~Data() {
            std::cout << "\nDestruindo objeto data: ";
        }

    private:
        int dia;
        int mes;
        int ano;
};