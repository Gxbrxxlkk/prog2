#include "data.h"

class Funcionario{
    //na construção, para data ter lugar onde ficar, funcionário tem que ser criado primeiro, para destruir, tira as partes de funcionario (data) e depois destroi o funcionario
    public:
        Funcionario(std::string um_nome, Data nasc, Data adm) : nome{um_nome}, dataNascimento{nasc}, dataAdmissao{adm} {
            std::cout << "\n Criando o objeto funcionario";
        }
    
        std::string toString() {
            std::string aux{"\nNome: " + nome + "\nData de nascimento: " + dataNascimento.toString() + "\nData de admissão: " + dataAdmissao.toString()};
            return aux;
        }

        ~Funcionario() {
            std::cout << "\nFuncionario sendo destruido";
        }


    private:
        std::string nome{}; //composicao
        Data dataNascimento{}; //composição (parte);
        Data dataAdmissao{}; //composição
};