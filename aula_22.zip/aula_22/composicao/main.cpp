#include "func.h"

int main() {
    Funcionario f1{"Zé da manga", Data{10,1,1945} , Data{11,9,2001}};

    //std::cout << f1.toString() << std::endl;
    
    return 0;
}