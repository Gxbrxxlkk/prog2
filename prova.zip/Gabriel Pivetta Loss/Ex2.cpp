#include <array>
#include <iostream>
#include <string>
#include <vector>


void mostra(const std::array<std::array<char, 3>, 3> &tabuleiro);
bool marca(std::array<std::array<char, 3>, 3> &tabuleiro, int x, int y, char ch);
bool ganhou(const std::array<std::array<char, 3>, 3> &tabuleiro, char ch);
bool empate(const std::array<std::array<char, 3>, 3> &tabuleiro);

int main() {

    //declaração de variaveis
    //std::string mtz[3][3]; //linder: pedi com array c++
    std::array<std::array<char, 3>, 3> tabuleiro{std::array<char, 3> {' ', ' ', ' '},
                                                 std::array<char, 3> {' ', ' ', ' '},
                                                 std::array<char, 3> {' ', ' ', ' '}};
    // int linha, coluna, jogadas, x_ou_o;
    // bool ganhou {false};
    // std::array <std::string, 2> simbolo {"X", "O"};
    // std::vector<std::string> diagonal;
    // std::vector<std::string> diagonal_inv;

    // //valor máximo possivel de jogadas é 9
    // jogadas = 0;

    // //Inicialização da matriz
    // for(int i{0}; i < 3; i++) {
    //     for(int j{0}; j < 3; j++) {
    //         tabuleiro.at(i).at(j) = ""; //linder: errado! mtz é array c
    //     } //tabuleiro[i][j] testar em casa trocar todos os at por o metodo do C
    // }

    // //enquanto ninguem ganhar ou empatar, o loop continuará
    // while(!ganhou) 
    // {
    //     std::cout << "Insira a linha e a coluna onde quer adicionar, seguido de qual simbolo marcar (0 para 'X' e 1 para 'O'): " << std::endl;

    //     do {
    //         std::cin >> linha >> coluna >> x_ou_o; //recebe o valor da linha, coluna e qual simbolo
    //         if(!(mtz.at(linha).at(coluna).empty())) { //verifica se a posição que o usuário escolheu não está vazia
    //             std::cout << "Posição já ocupada, insira novamente: " << std::endl;
    //         }
    //     } while(!(mtz.at(linha).at(coluna).empty())); //enquando não for uma entrada válida, continuará repetindo

    //     mtz.at(linha).at(coluna) = simbolo.at(x_ou_o); //insere o simbolo na matriz na posição que o usuário escolheu

    // //para verificar se a diagonal foi preenchida, e se todos os valores nela são iguais
    
    //     if(linha == coluna) {
    //         diagonal.push_back(mtz[linha][coluna]);
    //         if(diagonal.size() == 3) {
    //             if (diagonal[0] == diagonal[1] && diagonal[1] == diagonal[2]) ganhou = true;
    //         }
    //     } 
    // //para verificar se a diagonal da direita pra esquerda foi totalmente preenchida, e se todos os valores nela são iguais
    //     else if((linha == coluna) || (linha == 0 && coluna == 2) || (linha = 2 && coluna == 0)) {
    //         diagonal_inv.push_back(mtz[linha][coluna]);
    //         if(diagonal_inv.size() == 3) {
    //             if(diagonal_inv[0] == diagonal_inv[1] && diagonal_inv[1] == diagonal[2]) ganhou = true;
    //         }
    //     }
    
    //     //para verificar as linhas e colunas
    //     for (int l = 0; l < 3; l++) {
    //         if(mtz[l][0] == mtz[l][1] && mtz[l][1] == mtz[l][2]) { //se todos da mesma linha forem iguais, ganhou = true
    //             ganhou = true;
    //         }
    //         for (int m = 0; m < 3; m++) {

    //             if(mtz[0][m] == mtz[1][m] && mtz[1][m] == mtz[2][m]) { //se todos da coluna forem iguais, ganhou = true
    //             ganhou = true;

    //             } 
    //         }
    //     }
    //     //se ninguem ganhou nessa iteração, aumenta o numero de jogadas
    //     jogadas++;
    //     if(jogadas == 9) {
    //         std::cout << "Temos um empate!" << std::endl;
    //         break;
    //     }
    // }

    // if(ganhou) {
    //     std::cout <<"Temos um vencedor!" << std::endl;
    // }

    while (true) {
        //jogador 1
        int x{-1}, y{-1};
        std::cout << "\nJogador 1: Informe as coordenadas (x,y) da jogada: ";
        std::cin >> x >> y;
        while (!marca(tabuleiro,x,y, 'X'))
        {
        mostra(tabuleiro);
        std::cout << "\nJogador 1: invalido (x,y) da jogada: ";
        std::cin >> x >> y;            
        }
        mostra(tabuleiro);
        
        //verifica se 
        if(ganhou(tabuleiro,'X')) {
            std::cout << "\nJogador 1 ganhou!!";
            break;
        }
        if (empate(tabuleiro)) {
            std::cout << "\nJogo terminou empatado!";
            mostra(tabuleiro);
            break;
        }
        
        int n{-1}, m{-1};
        std::cout << "\nJogador 2: Informe as coordenadas (x,y) da jogada: ";
        std::cin >> n >> m;
        while (!marca(tabuleiro,n,m, 'O'))
        {
        mostra(tabuleiro);
        std::cout << "\nJogador 2: invalido (x,y) da jogada: ";
        std::cin >> n >> m;            
        }
        mostra(tabuleiro);
        
        //verifica se 
        if(ganhou(tabuleiro,'X')) {
            std::cout << "\nJogador 2 ganhou!!";
            mostra(tabuleiro);
            break;
        }
        mostra(tabuleiro);
    }

    return 0;
}

void mostra(const std::array<std::array<char, 3>, 3>& tabuleiro) {
    for (int i = 0; i < tabuleiro.size(); i++) {  // Corrigido o critério de iteração das linhas
        for (int j = 0; j < tabuleiro[i].size(); j++) {  // Itera sobre as colunas
            std::cout << "|" << tabuleiro[i][j];  // Imprime cada célula com '|' separando
        }
        std::cout << "|\n";  // Imprime a borda vertical e uma quebra de linha ao final de cada linha
        if (i < 2) {  // Não precisa de linha divisória após a última linha
            std::cout << "-------\n";  // Imprime a linha divisória entre as linhas do tabuleiro
        }
        
    }
    std::cout << "\n" << std::endl;
}

bool marca(std::array<std::array<char, 3>, 3> &tabuleiro, int x, int y, char ch) {
    if (tabuleiro.at(x).at(y) == ' ') {
        tabuleiro.at(x).at(y) = ch;
        return true;
    }
    return false;
}

bool ganhou(const std::array<std::array<char, 3>, 3> &tabuleiro, char ch) {
    for (int i = 0; i < tabuleiro.size(); i++) {
        if((tabuleiro[i][0] == ch) && (tabuleiro[i][1] == ch) && (tabuleiro[i][2] == ch)) {
            return true;
        }
        if((tabuleiro[0][i] == ch) && (tabuleiro[1][i] == ch) && (tabuleiro[2][i] == ch)) {
            return true;
        }
    }

    //verificar na diagonal
    if((tabuleiro[0][0] == ch) && (tabuleiro[1][1] == ch) && (tabuleiro[2][2] == ch)) return true;
    if((tabuleiro[2][0] == ch) && (tabuleiro[1][1] == ch) && (tabuleiro[0][2] == ch)) return true;

    return false;
}

bool empate(const std::array<std::array<char, 3>, 3> &tabuleiro) {
    for (int i = 0; i < tabuleiro.size(); i++)
    {
        for (int j = 0; j < tabuleiro[0].size(); j++)
        {
            if (tabuleiro[i][j] == ' ') {
                return false;
            }
        }
        
    }
    return true;
}