/*
19. Dado que podemos calcular ex por: ex = 1 + x + x2/2! + x3/3! + ...Faça uma função
que leia o valor de x e calcule o valor de ex. O valor deve ser calculado enquanto o
termo calculado for maior que 10E-6.
*/

#include <iostream>
#include <cmath>

double euler(int);
unsigned int factorial(unsigned int);


int main() {

    int x{0};

    std::cout << "Insira um valor x para calcular e^x: " << std::endl;

    std::cin >> x;

    std::cout << "O valor de e^" << x << " é: " << euler(x) << std::endl;

    return 0;
}

unsigned int factorial(unsigned int x) {

    unsigned int result{1};

    while (x != 0) {
        
        result *= x;
        --x;
    }
    return result;
}

double euler(int x) {

    double result{0.0};
    double term{1.0};
    int n{1};

    while (fabs(term) >= 1e-6 || n == x)
    {
        result += term;

        term = pow(x, n) / factorial(n);
        ++n;
    }
    
    return (double) result;
}