/*
20. Implemente um função genérica (template) chamada maximoDeTres() que receba
três argumentos de mesmo tipo e retorne o maior deles. A função deve funcionar
para tipos primitivos como int, double, char, etc. O programa principal (main)
deve demonstrar a função com três inteiros, três números de ponto flutuante e três
caracteres.
*/

#include <iostream>


template <typename T>
T maximoDeTres(T, T, T);

int main() {

    std::cout << "O maior entre 15, 19 e 22 é: " << maximoDeTres(15, 19, 22) << std::endl;

    std::cout << "O maior entre 0.75, 1.25 e 1.5 é: " << maximoDeTres(0.75, 1.25, 1.50) << std::endl;

    std::cout << "O maior entre G, P e L é: " << maximoDeTres('G', 'P', 'L') << std::endl;

    return 0;
}

template <typename T>
T maximoDeTres(T x, T y, T z) {

    if (x > y) {
        if (x > z) return x;
        else return z;
    } else if (y > z) {
        return y;
    } else return z;

}