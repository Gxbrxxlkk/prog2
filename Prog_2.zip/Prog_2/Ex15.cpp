/*
15. Escreva uma função que calcule a distância entre dois pontos cujas coordenadas
devem ser informadas como parâmetro (x1, y1) e (x2, y2) .
*/

#include <iostream>
#include <cmath>

float dist_2_points(float, float, float, float);



int main() {

    float x1, x2, y1, y2, dist;

    std::cout << "Insira as cordenadas separadas por espaço (x1 y1 x2 y2): " << std::endl;

    std::cin >> x1 >> y1 >> x2 >> y2;
    dist = dist_2_points(x1,y1,x2,y2);

    std::cout << "A distância entre os pontos é: " << dist << std::endl; 
}

float dist_2_points(float x1, float y1, float x2, float y2) {

    return sqrt(pow(x2-x1, 2) + pow(y2-y1, 2));
}