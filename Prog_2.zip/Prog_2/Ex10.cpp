/*
10. Faça uma função que receba duas strings e retorne uma string formada pela
concatenação das strings recebidas. Exemplo: Se a primeira string digitada for
"Bom dia, " e a segunda "moçada !", então o resultado é "Bom dia, moçada !".
*/

#include <string>
#include <iostream>

std::string concat(std::string, std::string);

int main() {
    
    std::string word;
    std::string word1;
    std::string new_word;
    
    std::cout << "Insira duas strings para realizar a concatenação: " << std::endl;

    std::getline(std::cin, word);
    std::getline(std::cin, word1);

    new_word = concat(word, word1);

    std::cout << "O resultado é: \n" << new_word << std::endl;

    return 0;
}

std::string concat(std::string word, std::string word1) {
    return word + word1;
}