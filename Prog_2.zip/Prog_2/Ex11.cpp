/*
11. Escreva um programa para ajudar um aluno do ensino fundamental a aprender
mulIplicação. Crie uma função que gere e retorne aleatoriamente dois números
inteiros posiIvos de um dígito. Use o resultado dessa função em seu script para
solicitar ao usuário uma pergunta, como “Quanto é 6 vezes 7?”. Para uma resposta
correta, exiba a mensagem "Muito bom!" e faça outra pergunta de mulIplicação.
Para uma resposta incorreta, exiba a mensagem "Não. Tente novamente." e deixe
o aluno tentar a mesma pergunta repeIdamente até que ﬁnalmente acerte.
*/

#include <iostream>
#include <random>
#include <array>

std::array<int,2> two_numbers();

int main() {

    int correct_answers{0};

    while (correct_answers != 10)
    {

        int answer{0};
        std::array <int, 2> numbers = two_numbers();

        do
        {
            std::cout << "Quanto é " << numbers[0] << " vezes " << numbers[1] << "?" << std::endl;
            std::cin >> answer;
            
        if (answer == (numbers[0] * numbers[1])) {
            std::cout << "Muito bom!" << std::endl;
        } else {
            std::cout << "Tente novamente" << std::endl;
        }

        } while (answer != (numbers[0] * numbers[1]));

        ++correct_answers;
    }

    return 0;
}

std::array<int,2> two_numbers() {

    static std::random_device seed;
    static std::default_random_engine engine(seed());
    static std::uniform_int_distribution gerador(1,9); 

    int number{gerador(engine)};
    int number1{gerador(engine)};
    return {number, number1};
}
