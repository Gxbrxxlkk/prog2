/*
14. Construa um programa que leia duas strings do teclado. Imprima uma mensagem
informando se a segunda string lida está conIda dentro da primeira.
*/

#include <iostream>
#include <string>

int main() {

    std::string word, word1;
    bool contained;

    std::cout << "Insira duas strings, para verificar se a segunda está contida na primeira: " << std::endl;

    getline(std::cin, word);
    getline(std::cin, word1);


    if (word1.size() <= word.size()) {
        for (size_t i = 0; i <= word.size() - word1.size(); i++) {
            contained = true;  // Supõe que encontrou nesta posição
            for (size_t j = 0; j < word1.size(); j++) {
                if (word[i + j] != word1[j]) {
                    contained = false;  
                    break;              // Sai para próxima posição
                }
            }
            if (contained) break;  // Achou a substring, sai do loop externo
        }
    }

    if (contained) {
        std::cout << "A segunda string está contida na primeira" << std::endl;
    } else {
        std::cout << "A segunda string está não está contida na primeira" << std::endl;
    }
    return 0;
}