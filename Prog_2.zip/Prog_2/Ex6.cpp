/*
6. Escreva um programa que calcule a média e a moda de uma sequência de valores
inteiros fornecidos pelo usuário.
*/

#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    //declaração de variaveis
    std::vector <int> sequence;
    int x{0};
    int qtd_num{0};
    double media = 0.0f;
    int moda{0};
    int repeticoes{1};
    int repeticoes_ant{0};

    //Inserir um numero por vez, utilizando enter para seguir para o próximo numero
    std::cout << "Insira os valores para calcular a média e a moda. Utilize Ctrl + d quando terminar de inserir (ou Ctrl + z no Windows): " << std::endl;

    while (std::cin >> x) {
        sequence.push_back(x);
    }

    //Verifica se não foi inserido nada
    if (sequence.empty()) {
    std::cout << "Nenhum número foi inserido.\n";
    return 0;
    }
    

    for (int numero : sequence) {
        media += numero;
    }
    //divide a soma de todos os numeros, pela quantidade de numeros
    media /= sequence.size();
    
    std::cout << "\nA média dos valores inseridos é: " << media << std::endl;
    
    //Coloca os numeros em ordem crescente para realizar a verificação de qual numero tem a maior moda
    std::sort(sequence.begin(), sequence.end());

    for (int i = 0; i < sequence.size() - 1; i++) {
        if (sequence.at(i) == sequence.at(i+1)) {

            repeticoes++;
            
        } else if (repeticoes > repeticoes_ant) {

            moda = sequence.at(i);
            repeticoes_ant = repeticoes;
            repeticoes = 1;
        }
    } 
    //Verificação do ultimo grupo de numeros
    if (repeticoes > repeticoes_ant) {
            moda = sequence[sequence.size() - 1];
    }

    std::cout << "A moda da sequência inserida é: " << moda << std::endl;


    return 0;
}