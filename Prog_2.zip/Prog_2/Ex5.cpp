/*
5. Escreva um programa que receba um inteiro contendo 0s e 1s representando um
número binário e exiba seu equivalente decimal.
*/

#include <iostream>
#include <string>
#include <cmath>

int main() {

    std::string numero;
    int decimal{0};

    std::cout << "Insira um numero em binário para a conversão: ";
    std::cin >> numero;

    for (int i = 0; i < numero.length(); i++) {
        if (numero.at(i) == '1') {
            decimal += pow(2, numero.length() - (i + 1));
        }
    }

    std::cout << "O numero em decimal é: " << decimal << std::endl;
    
    return 0;
}