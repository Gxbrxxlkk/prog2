/*
18. Escreva uma função que receba como parâmetro um valor inteiro e posiIvo N e
retorna o valor S = 1 + 1/1! + 1/2! + 1/3! +...+ 1 /N!
*/

#include <iostream>

double math_func(unsigned int);
unsigned int factorial(unsigned int);

int main() {

    unsigned int x{0};
    float result;

    std::cout << "Escreva um numero para fazer a função matemática: " << std::endl;

    std::cin >> x;

    result = math_func(x);

    std::cout << "O resultado da função matemática é: " << result << std::endl;

    return 0;
}

unsigned int factorial(unsigned int x) {

    unsigned int result{1};

    while (x != 0) {
        
        result *= x;
        --x;
    }
    return result;
}

double math_func(unsigned int x) {

    double result{1};

    while (x != 0) {
        
        result += 1.0/factorial(x);

        --x;
    }
    
    return (double) result;
}

// As funções feitas com recursividade, não é possivel usar valores acima de 34, tamanho da pilha muito grande.

// unsigned int factorial(unsigned int x) {
//     if (x == 0) return 1;
//     return x * factorial(x-1);
// }

// double math_func(unsigned int x) {

//     if (x == 0) return 1;
//     return (float) 1/factorial(x) + math_func(x - 1);

// }