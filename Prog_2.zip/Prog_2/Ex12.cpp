/*
12. Faça um programa que leia uma string e a imprima de trás para frente.
*/

#include <iostream>
#include <string>

int main() {

    std::string word;
    std::string new_word;

    std::cout << "Escreva uma frase para receber o inverso dela: " << std::endl;

    std::getline(std::cin, word);

    for (char c : word) {
        new_word.insert(new_word.begin(), c);
    }

    std::cout << "A frase invertida é: " << new_word << std::endl;


    return 0;
}