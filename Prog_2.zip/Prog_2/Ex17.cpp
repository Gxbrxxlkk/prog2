/*
17. Escreva uma função que receba por parâmetro dois valores X e Z e calcule xz. (sem
uIlizar funções ou operadores de potência prontos).
*/

#include <iostream>

float pow(float, float);

int main() {

    float x, z, result;

    std::cout << "Insira os valores de x e z, para calcular a potencia: " << std::endl;

    std::cin >> x >> z;

    result = pow(x, z);

    std::cout << "A potencia de base " << x << " e expoente " << z << " é: " << result << std::endl;

    return 0;
}


float pow(float x, float z) {

    float result{x};

    for (int i = 1; i < z; i++) {
        result *= x;
    }
    return result;
}