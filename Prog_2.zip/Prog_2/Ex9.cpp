/*
9. Escreva uma função que receba uma string como parâmetro e retorne uma string
idênIca, mas com todos os caracteres converIdos para maiúsculo. Não use
métodos prontos da classe string. Dicas: O código ASCII da letra ‘a’ (minúsculo) é
97 e o código da letra ‘A’ (maiúsculo) é 65, o código da letra ‘z’ é 122 e o código da
letra ‘Z’ é 90. Cuidado para não acabar convertendo aquilo que não é nem texto e
nem está em minúsculas!.
*/

#include <string>
#include <iostream>

std::string upper_case(std::string);

int main() {

    std::string word;
    std::string new_word;
    std::cout << "Insira uma string, para converter as letras para maiusculo: " << std::endl;
    //std::cin >> word; << só captura uma palavra (texto sem espaço)
    std::getline(std::cin, word);

    new_word = upper_case(word);

    std::cout << "A palavra com tudo maiusculo é: \n" << new_word << std::endl;

    return 0;
}

std::string upper_case(std::string word) {

    std::string upper_word;

    for (int i = 0; i < word.size(); i++) {
        if (word[i] >= 'a' && word[i] <= 'z') upper_word.push_back(word[i] - 32);
        else upper_word.push_back(word[i]); 
    }
    
    return upper_word;
}