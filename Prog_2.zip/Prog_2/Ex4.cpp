/*
4. Implemente um programa que empregue um loop for e os recursos de
manipulação de strings para produzir a tabela a seguir com os números alinhados
à direita em cada coluna.
*/

#include <iostream>
#include <string>

int main() {

    int largura{10};
    std::cout << std::string(largura - 7, ' ') << "Número:" << std::string(largura - 9, ' ') << "Quadrado:" << std:: string(largura - 5, ' ') << "Cubo:" << std::endl;

    for (int i{0}; i<=5; i++) {
        std::string string_num = std::to_string(i);
        std::string string_quad = std::to_string(i*i);
        std::string string_cubo = std::to_string(i*i*i);

        std::cout << std::string(largura - string_num.length(), ' ') << string_num << std::string(largura - string_quad.length(), ' ') << string_quad << std::string(largura - string_cubo.length(), ' ') << string_cubo << std::endl;
    }
}