/*
7. Escreva um programa para o jogo "adivinhe o número". Escolha o número a ser
adivinhado selecionando um número inteiro aleatório no intervalo de 1 a 1000.
Não revele esse número ao usuário. Exiba o prompt "Adivinhe o número que está
entre 1 e 1000 com o menor número de tentaIvas:". O jogador insere um primeiro
palpite. Se o palpite esIver incorreto, exiba "Muito alto. Tente novamente." ou
"Muito baixo. Tente novamente." conforme apropriado para ajudar o jogador a
"acertar" a resposta correta e, em seguida, solicite ao usuário o próximo palpite.
Quando o usuário inserir a resposta correta, exiba "Parabéns. Você acertou o
número!" e permita que o usuário escolha se deseja jogar novamente.
*/

#include <iostream>
#include <random>

int main() {

    std::random_device seed;
    std::default_random_engine engine{seed()};
    std::uniform_int_distribution gerador{1,1000};
    int numero{gerador(engine)};
    int x{0};
    std::cout << "Adivinhe o numero entre 1 a 1000:" <<  numero << std::endl;
    bool adivinhou{false};

    while (!adivinhou) {
        
        std::cin >> x;

        int diferenca = numero - x;

        if (x == numero) {
            std::cout << "Parabéns. Você acertou o número!" << std::endl;
            adivinhou = true;
            break;
        } else if (diferenca > 300) std::cout << "Muito baixo. Tente novamente\n";
        else if (diferenca < -300) std::cout << "Muito alto. Tente novamente\n";
        else if (diferenca > 100) std::cout << "Meio baixo. Tente novamente\n";
        else if (diferenca < -100) std::cout << "Meio alto. Tente novamente\n";
        else if (diferenca > 10) std::cout << "Perto, mas baixo ainda. Tente novamente\n";
        else if (diferenca < -10) std::cout << "Perto, mas alto ainda. Tente novamente\n";
        else std::cout << "Bem perto. Tente novamente\n";
    }

    return 0;
}
