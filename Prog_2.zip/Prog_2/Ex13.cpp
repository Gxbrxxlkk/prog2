/*
13. Escreva um programa que leia uma linha de texto e separe as “palavras” usando
caracteres de espaço como delimitadores. Mostre as palavras obIdas.
*/

#include <iostream>
#include <string>
#include <vector>


int main() {

    std::string line;
    std::vector <std::string> words;
    std::string temp_word;

    std::cout << "Escreva uma linha de texto: " << std::endl;

    std::getline(std::cin, line);

    for (int i = 0; i < line.size(); i++) {
        if (line[i] != ' ') {
            temp_word.push_back(line[i]);
        } else {
            words.push_back(temp_word);
            temp_word = "";
        }
    }
    if (!temp_word.empty()) {
        words.push_back(temp_word);
    }

    std::cout << "As \"palavras\" na linha inserida são: " << std::endl;
    for (std::string word : words) {
        std::cout << word << std::endl;
    }

    return 0;
}