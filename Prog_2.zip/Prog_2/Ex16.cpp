/*
16. Escreva uma função que receba 3 valores reais X, Y e Z e que veriﬁque se esses
valores podem ser os comprimentos dos lados de um triângulo. Para que X, Y e Z
formem um triângulo é necessário que a seguinte propriedade seja saIsfeita: o
comprimento de cada lado de um triângulo precisa ser menor do que a soma dos
comprimentos dos outros dois lados. A função deve retornar 0 se não for
triângulo; 1 se o triângulo for equilátero (3 lados são iguais); 2 se o triângulo
Isósceles (2 lados são iguais); 3 se o triângulo for escaleno (3 lados são diferentes).
Escreva um programa para testar a função.
*/

#include <iostream>

int is_triangle(float, float, float);

int main() {

    float X, Y, Z;
    int K;
    std::cout << "Insira 3 valores para verificar se é possivel formar um triangulo: " << std::endl;

    std::cin >> X >> Y >> Z;

    K = is_triangle(X, Y, Z);

    if (K == 0) {
        std::cout << "Não é triãngulo" << std::endl;
    } else if (K == 1) {
        std::cout << "É um triângulo equilatero" << std::endl;
    } else if (K == 2) {
        std::cout << "É um triângulo isósceles" << std::endl;
    } else if (K == 3) {
        std::cout << "É um triângulo escaleno" << std::endl;
    }
    

    return 0; 
}

int is_triangle(float X, float Y, float Z) {

    if (X < Y+Z || Y < X+Z || Z < X+Y) {
        if (X == Y && X == Z) {
            return 1;
        } else if (X != Y && X != Z) {
            return 3;
        } else return 2;
    } else return 0;
}