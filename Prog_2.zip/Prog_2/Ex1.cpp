/*
1. Um empregado recebe R$ 16,78 por cada hora trabalhada em uma semana. Se esse
empregado ﬁzer hora extra, deve receber o valor base acrescido de 50%. Do
pagamento bruto do empregado, 6% são reIdos pela Previdência Social, 14%, pelo
Receita Federal (imposto de renda), 5% pelo estado, e R$ 10 por semana para o
Sindicato. Se o empregado Iver três ou mais dependentes, um adicional de R$ 35
é reIdo para cobrir o custo extra do seguro de saúde. Com base nessas
informações, escreva um programa que receba como entrada o número de horas
trabalhadas em uma semana e o número de dependentes do empregado. O
programa deve apresentar como saída o pagamento bruto e o pagamento líquido
do empregado, bem como os valores reIdos por impostos.
*/

/*
Uma jornada normal de trabalho é 8 horas diárias com 44 semanais, a partir disso
é considerado hora extra.
*/

#include <iostream>


int main() {

    int horas_semanais{0};
    int qtd_dependentes{0};
    float salario_bruto{0.2f};
    const float valor_hora{16.78};
    float salario_liquido{0.2f};

    std::cout << "Insira a quantidade de horas trabalhadas por semana: ";
    std::cin >> horas_semanais;
    std::cout << "\nInsira o número de dependentes do empregado: ";
    std::cin >> qtd_dependentes;

    if (horas_semanais > 44) {
        int horas_extras = horas_semanais - 44;

        salario_bruto = 44 * valor_hora + (horas_extras * valor_hora * 1.5);
    } else {
        salario_bruto = horas_semanais * valor_hora;
    }
    std::cout << "\nPagamento bruto: " << salario_bruto << std::endl;

    if (qtd_dependentes >= 3) {
        salario_liquido = salario_bruto - (salario_bruto * 0.06 + salario_bruto * 0.14 + salario_bruto * 0.05 + 10 + 35); 
    } else {
        salario_liquido = salario_bruto - (salario_bruto * 0.06 + salario_bruto * 0.14 + salario_bruto * 0.05 + 10);
    }

    std::cout << "Pagamento liquido: " << salario_liquido << std::endl;
    std::cout << "Previdencia Social: " << (salario_bruto * 0.06) << "\nReceita Federal: " << (salario_bruto * 0.14) << "\nRetido pelo Estado: " << (salario_bruto * 0.05) << std::endl;

    return 0;
}