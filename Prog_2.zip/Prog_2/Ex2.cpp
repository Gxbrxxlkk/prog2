/*
2. Uma loja comercializa aparelhos com o seguinte plano de crediário: zero de
entrada, juros de 1,5% ao mês, e prestações mensais de R$ 50. A prestação mensal
de R$ 50 é uIlizada para pagar os juros, e o restante é uIlizado para amorIzar a
dívida remanescente. Por exemplo, se o aparelho custa R$ 1.000, no primeiro mês
você paga 1,5% de R$ 1.000 em juros. Isso dá R$ 15. Os R$ 35 restantes são
deduzidos do principal, o que o deixa com um débito de R$ 965,00. No mês
seguinte você paga um juro de 1,5% sobre R$ 965,00, que dá R$ 14,48. Assim, você
pode deduzir R$ 35,52 (R$ 50 – R$ 14,48) do que deve. Com base nessas
informações, escreva um programa que receba como entrada o preço de um
aparelho e lhe diga quantos meses você levará para pagar o que deve, bem como
a soma total paga em juros. UIlize um loop para calcular a soma paga em juros e o
tamanho do débito a cada mês. O úlImo pagamento pode ser inferior a R$ 50 se o
débito for menor, mas não se esqueça dos juros. Se você deve R$ 50, então sua
prestação mensal de R$ 50 não saldará seu débito, embora vá chegar perto disso.
*/

#include <iostream>

int main() {

    float valor_aparelho{0.0};
    float divida{0.0};
    float valor_pago_juros{0.0};
    int meses{0};
    const int prestacao{50};

    std::cout << "\nInsira o valor do aparelho: ";
    std::cin >> valor_aparelho;
    divida = valor_aparelho;
    while(divida > 0) {

        float juros_mes = divida * 0.015;
        float pagamento = (divida + juros_mes < 50.0f) ? (divida + juros_mes) : 50.0f;
        valor_pago_juros += juros_mes;
        divida += juros_mes - pagamento;
        meses++;
    }

    std::cout << "Meses necessários para pagar a divida: " << meses << "\nQuantidade paga em juros: " << valor_pago_juros << std::endl;


    return 0;
}