/*
21. Implemente uma funçã o chamada gerarID(string grupo) que retorna
um ID numérico único a cada chamada, com a base no grupo informado
como parâ metro. Existem dois grupos: “alunos e professores. Para
cada grupo o primeiro ID deve ser 1, o segundo 2, e assim por diante.
Alé m disso, o nú mero do ID deve ser precedido pelo nú mero do grupo.
*/

#include <string>
#include <iostream>

int idaluno{0};
int idprofessor{0};

int gerarID(std::string);

int main() {

    std::string alunos{"alunos"};
    std::string professores{"professores"};

    std::cout << "IDs de alunos: " << std::endl;
    for (int i = 0; i < 15; i++) {
        std::cout << gerarID(alunos) << std::endl;
    }
    
    std::cout << "\nIDs de professores:" << std::endl;
    for (int i = 0; i < 15; i++) {
        std::cout << gerarID(professores) << std::endl;
    }

    return 0;
}

int gerarID(std::string x) {
    
    if (x == "alunos") {
        std::string id = "1" + std::to_string(idaluno);
        int valor = std::atoi(id.c_str());
        ++idaluno;
        return valor;
    } else {
        std::string id = "2" + std::to_string(idprofessor);
        int valor = std::atoi(id.c_str());
        ++idprofessor;
        return valor;
    }
}