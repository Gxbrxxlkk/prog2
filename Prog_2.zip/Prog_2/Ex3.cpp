/*
3. A fórmula para calcular o Índice de Massa Corporal (IMC) é a seguinte: IMC = peso
(kg) / altura2 (m). Implemente uma calculadora de IMC que leia o peso do usuário
em quilogramas e a altura em metros e, em seguida, calcule e exiba o índice de
massa corporal do usuário. Além disso, a aplicação deve exibir a situação que se
encontra o usuário, de acordo com a tabela de IMC disponível em:
hhps://pt.wikipedia.org/wiki/Índice_de_massa_corporal
*/

#include <iostream>
#include <format>

int main() {

    float peso{0.0};
    float altura{0.0};
    float IMC{0.00f};

    std::cout << "\nInsira o peso e a altura separados por espaço: ";
    std::cin >> peso >> altura;

    IMC = peso / (altura * altura);

    std::cout << std::format("Seu IMC é: {:.2f}\n", IMC);

    if (IMC < 17.0) std::cout << "\nVocê está muito abaixo do peso" << std::endl;
    else if (IMC <= 18.49) std::cout << "\nVocê está abaixo do peso" << std::endl;
    else if (IMC <= 24.99) std::cout << "\nVocê está com o peso normal" << std::endl;
    else if (IMC <= 29.99) std::cout << "\nVocê está acima do peso" << std::endl;
    else if (IMC <= 34.99) std::cout << "\nVocê está com obesidade" << std::endl;
    else if (IMC <= 39.99) std::cout << "\nVocê está com obesidade severa" << std::endl;
    else std::cout << "\nVocê está com obesidade morbida" << std::endl;    

    return 0;
}