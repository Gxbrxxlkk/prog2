/*
8. Neste problema, recriaremos a clássica corrida da lebre e da tartaruga. Use geração
de números aleatórios para desenvolver uma simulação deste evento memorável.
Nossos compeIdores começam a corrida no quadrado 1 de 70 quadrados. Cada
quadrado representa uma posição ao longo do percurso. A linha de chegada é no
quadrado 70. O primeiro compeIdor a alcançar ou passar o quadrado 70 é
recompensado com um balde de cenouras e alface frescas. O percurso serpenteia
a encosta de uma montanha escorregadia, então ocasionalmente os compeIdores
perdem terreno. A cada segundo, sua aplicação deve ajustar a posição dos animais.
Use variáveis para acompanhar as posições dos animais (ou seja, os números das
posições vão de 1 a 70). Comece cada animal na posição 1 (o "ponto de parIda").
Se um animal deslizar para antes do quadrado 1, mova-o de volta para o quadrado
1. Crie duas funções que gerem os movimentos da tartaruga e da lebre,
respecIvamente, produzindo um inteiro aleatório i no intervalo 1 ≤ i ≤ 10. Na
função para a tartaruga, execute um "andar lento" quando 1 ≤ i ≤ 5, um
"escorregão" quando 6 ≤ i ≤ 7 ou um "andar lento" quando 8 ≤ i ≤ 10. Elabore uma
técnica semelhante na função para a lebre.
*/

#include <random>
#include <iostream>

int mov_tartaruga(int*);
int andar_lento(int*);
int escorregao(int*);
int andar_rapido(int*);
int mov_lebre(int*);



int main() {

    int tartaruga{1};
    int lebre{1};

    while (lebre < 70 && tartaruga < 70) {

        mov_tartaruga(&tartaruga);
        mov_lebre(&lebre);

        if (lebre < 1) lebre = 1;
        if (tartaruga < 1) tartaruga = 1;

        if (lebre >= 70) {
            std::cout << "\nA Lebre venceu a corrida!";
            break;
        } else if (tartaruga >= 70) {
            std::cout << "\nA Tartaruga venceu a corrida!";
            break;
        }   
    }
    return 0;
}


int mov_tartaruga(int *pos) {
    
    static std::random_device seed;
    static std::default_random_engine engine{seed()};
    static std::uniform_int_distribution gerador{1,10};
    int numero{gerador(engine)};

    if (numero <=5 || numero >= 8) {
        andar_lento(pos);
    } else {
        escorregao(pos);
        std::cout << "\nA Tartaruga escorregou!";
    }
    return 1;
}

int mov_lebre(int *pos) {
    
    static std::random_device seed;
    static std::default_random_engine engine{seed()};
    static std::uniform_int_distribution gerador{1,10};
    int numero{gerador(engine)};
    
    if (numero <=4 || numero >= 9) {
        andar_rapido(pos);
    } else {
        escorregao(pos);
        std::cout << "\nA Lebre escorregou!";
    }
    return 1;
}

int andar_lento(int *x) {
    return *x += 5;
}

int andar_rapido(int *x) {
    return *x += 7;
}

int escorregao(int *x) {
    return *x -= 2;
}