#include "Ex3.h"

int main() {
    
    Lista minha_lista{};
    minha_lista.insereFinal(10);
    minha_lista.insereInicio(15);
    minha_lista.insereFinal(-13);
    minha_lista.insereFinal(21);
    minha_lista.insereInicio(7);

    minha_lista.mostraLista();

    return 0;
}