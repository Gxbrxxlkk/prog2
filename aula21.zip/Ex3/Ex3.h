#include <iostream>

class No {

    public:

        int valor;
        No* prox;

    //Construtor
    No(int val): valor{val}, prox{nullptr} {}
      
};

class Lista{

    public:

        Lista(): inicio{nullptr} {}
        bool insereInicio(int valor) {
            No* aux = new No(valor);
            if (inicio == nullptr) {
                inicio = aux;
                return true;
            } else {
                aux->prox = inicio;
                inicio = aux;
                return true;
            }
            return false;
        }

        bool insereFinal(int valor) {
            No* aux = inicio;
            No* novo_no = new No(valor);

            if (inicio == nullptr) {
                inicio = novo_no;
                return true;
            } else {
                while (aux->prox != nullptr) {
                    aux = aux->prox;

                }
                aux->prox = novo_no;
                return true;
            }
        }

        void mostraLista() {
            
            No* aux = inicio;
            while (aux != nullptr) {
                std::cout << "Valor = " << aux->valor << std::endl;
                aux = aux->prox;
            }
        }

            
        ~Lista() {
            std::cout << "Oi! Vou te DESTRUIR!!" << std::endl; 
            if (inicio != nullptr){
                No* atual{inicio};
                No* seguinte{nullptr};
                while (atual != nullptr) {
                    seguinte = atual->prox;
                    delete atual;
                    atual = seguinte;
                }
                
            }
            
        }

    private:
        No* inicio;

};