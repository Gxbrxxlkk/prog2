#include <string>

class Conta  { //Convenção, nome de classe com letra maiuscula

    //definindo os métodos que formam a interface da classe
    public:
        //construtores: metodos iniciais para criar os objetos (compilador cria automatico, mas é melhor criar a mão) Não retorna valores. Tem o mesmo nome da classe 
        Conta() :nome{""}, cpf{""}, numero{0}, saldo{0} {}
        Conta(std::string nomeCli, std::string cpfCli, int numeroConta, float saldoConta)
        :nome{nomeCli}, cpf{cpfCli}, numero{numeroConta} {
            if (saldoConta > 0) {
                saldo = saldoConta;
            } else {
                saldo = 0.0;
            }
        }

        //métodos de acesso (getters and setters)
        //getters:
        std::string getNome() {
            return nome;
        }
        std::string getCpf() {
            return cpf;
        }
        int getNumero() {
            return numero;
        }
        float getSaldo() {
            return saldo;
        }

        //setters
        void setNome(std::string nomeCli) {
            nome = nomeCli;
        }
        void setCpf(std::string cpfCLi) {
            cpf = cpfCLi;
        }
        void setNumero(int novoNumero) {
            numero = novoNumero;
        }
        void setSaldo(float saldoInicial) {
            
            if (saldoInicial >= 0) saldo = saldoInicial;
            else saldo = 0;
        }

     //métodos para conduzir saque e depósito
        bool sacar(float valor) {
            if ((valor > 0) && (valor <= saldo)) {
                saldo -= valor;
                return true;
            } else return false;
        }

        void depositar(float valor) {
            if (valor > 0) saldo += valor;
        }

    //Definindo dados membros
    private:
        std::string nome;
        std::string cpf;
        int numero;
        float saldo;

};