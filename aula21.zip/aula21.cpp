#include <iostream>
#include <array>

void cubo1(int* valor);
void cubo2(int& valor);


int main() {



    //declaração e inicialização de ponteiros

    int x{10};
    int y{10};
    int* p = new int{42};  // aloca um int no heap e inicializa com 42
    
    int meuArrayC[5] {1,2,3,4,5};
    std::array<int, 5> meuArrayCpp = std::to_array(meuArrayC);

    // //ponteiro não constante para variaveis constantes
    // const int* ptr{nullptr};
    // ptr = &x; //ok
    // ptr = &y; //ok
    // //*ptr = 35; //erro

    // //ponteiro constante para variaveis não constantes
    // int* const ptr{&x}; //ok
    // *ptr = 35; // ok
    // ptr = &y; //erro
    


    cubo1(&x);
    cubo2(y);

    std::cout << "X³ = " << x << std::endl;
    std::cout << "Y³ = " << y << std::endl;

    // int* ptr{nullptr};
    // ptr = &x; //extraindo o endereço

    // std::cout << "Endereço de x = " << &x << std::endl;
    
    
    // std::cout << "Valor de x = " << *ptr << std::endl;
    
    // // operador *: usado para derreferenciar (eliminar a indireao) do ponteiro
    // *ptr = 15;
    // std::cout << "Valor de x = " << x << std::endl;
    return 0;
}


void cubo1(int* valor) {
    *valor *= (*valor) * (*valor);
}
void cubo2(int& valor) {
    valor *= valor * valor;
}