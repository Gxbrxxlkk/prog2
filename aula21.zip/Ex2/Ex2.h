#include <string>
class Data {
    
    public:


        Data() : 
        dia{}, mes{}, ano{}{}
        Data(int d, int m, int a) : dia{d}, ano{a} {
            if (m >= 1 && m <= 12) mes = m;
            else mes = 1;
        }


        int getDia() {return dia;}
        int getMes() {return mes;}
        int getAno() {return ano;}

        void getData();

        void setDia(int d) {
            dia = d;
        }
        void setMes(int m) {
            if (m >= 1 && m <= 12) mes = m;
            else mes = 1;
        }
        void setAno(int a) {
            ano = a;
        }


    private:
        int dia;
        int mes;
        int ano;
};