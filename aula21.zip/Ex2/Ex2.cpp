#include "Ex2.h"
#include <iostream>

void Data::getData() {
    std::cout << dia << "/" << mes << "/" << ano << std::endl;
}

