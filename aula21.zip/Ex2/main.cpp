#include "Ex2.h"

int main() {

    Data umadata{13,02,2006};
    umadata.getData();

    umadata.setAno(2069);
    umadata.setDia(157);
    umadata.setMes(13);

    umadata.getData();

    return 0;
}